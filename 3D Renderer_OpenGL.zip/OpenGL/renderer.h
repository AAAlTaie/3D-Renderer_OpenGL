// Used to print debug infomation from OpenGL, pulled straight from the official OpenGL wiki.

void PrintLabeledDebugString(const char* label, const char* toPrint)
{
	std::cout << label << toPrint << std::endl;
#if defined WIN32 //OutputDebugStringA is a windows-only function 
	OutputDebugStringA(label);
	OutputDebugStringA(toPrint);
#endif
}

#ifndef NDEBUG
void APIENTRY
MessageCallback(GLenum source, GLenum type, GLuint id, GLenum severity, GLsizei length, const GLchar* message, const void* userParam) 
{
	std::string errMessage;
	errMessage = (type == GL_DEBUG_TYPE_ERROR ? "** GL ERROR **" : "");
	errMessage += " type = ";
	errMessage += type;
	errMessage += ", severity = ";
	errMessage += severity;
	errMessage += ", message = ";
	errMessage += message;
	errMessage += "\n";
	PrintLabeledDebugString("GL CALLBACK: ", errMessage.c_str());
}
#endif

// Creation, Rendering & Cleanup
class Renderer
{

	// TODO: Part 1c
	struct Vertex { float x, y, z, w; };

	//SYSTEM: proxy handles
	GW::SYSTEM::GWindow win;
	GW::GRAPHICS::GOpenGLSurface ogl;
	GW::CORE::GEventReceiver _shutdown;        //to end the show 

	// TODO: Part 2a
	GW::MATH::GMATRIXF _matrix_X, _matrix_Y; //-------ID X,Y
	GW::MATH::GMatrix _matrixProxy;         //------Matrix proxi
	GW::MATH::GVector _vecProxy;           //------- vector prxi

	// TODO Input + controller 
	GW::INPUT::GInput _GInput;
	GW::INPUT::GController _GController;

    // TODO: Part 1d
	GW::MATH::GMATRIXF _Griddy_McGrid_face;
	GW::MATH::GMATRIXF _Griddy_McGrid_LeftCheek;
	GW::MATH::GMATRIXF _Griddy_McGrid_RightCheek;
	GW::MATH::GMATRIXF _Griddy_McGrid_BackCheeks;
	GW::MATH::GMATRIXF _Griddy_McGrid_Head;
	GW::MATH::GMATRIXF _Griddy_McGrid_Feet;

	GW::MATH::GMATRIXF _matrixCameraMan_Out;

	// TODO: Part 2e
	GW::MATH::GMATRIXF _veiwMatrix;     // -------------(View Matrix)
	GW::MATH::GMATRIXF _LPMatrix;      // ------ (matrix --> Left Perspctive)
	GW::MATH::GMATRIXF _view_AND_Perspective;   // AND prospective
	GW::MATH::GMATRIXF _worldCameraMan;        // WCM

	// TODO: Part 3a
	GW::MATH::GMATRIXF _ProjMatrix; // projection matrix

	// what we need at a minimum to draw a triangle
	GLuint vertexArray = 0;
	GLuint vertexBufferObject = 0;
	GLuint vertexShader = 0;
	GLuint fragmentShader = 0;
	GLuint shaderExecutable = 0;

public:


	struct VShader
	{
		GW::MATH::GMATRIXF _MatrixWorld, _MatrixView, _ProjMatrix;

	};

	VShader _worldShader;
	

	Renderer(GW::SYSTEM::GWindow _win, GW::GRAPHICS::GOpenGLSurface _ogl)
	{
		win = _win;
		ogl = _ogl;

		unsigned int _width;
		win.GetClientWidth(_width);

		unsigned int _height;
		win.GetClientHeight(_height);

		_GController.Create();
		_GInput.Create(win);

		_matrixProxy.Create(); // Proxy
		_vecProxy.Create();   // Vector Proxy

		GW::MATH::GVECTORF _vectorProxy = { 0.0f, -0.5f, 0.0f, 1.0f };
		_matrixProxy.IdentityF(_matrix_X);
		_matrixProxy.IdentityF(_matrixCameraMan_Out);

		_worldShader._MatrixWorld = GW::MATH::GIdentityMatrixF;  //  World Matrix


		//_worldShader._MatrixWorld.row4.y = -0.5f; /// 
		_matrixProxy.TranslateGlobalF(_matrix_X, _vectorProxy, _matrix_X);  //--------- Bug?

		GW::MATH::GVECTORF fov =        { 0.25f, -0.25f, -0.25f, 0.0f };
		GW::MATH::GVECTORF posView =    { 0.0f,  -0.5f,  0.0f, 0.0f };
		GW::MATH::GVECTORF globalView = { 0.0f,  1.0f,  0.0f, 0.0f };

		_matrixProxy.LookAtLHF(fov, posView, globalView, _veiwMatrix);

		_worldShader._MatrixView = _veiwMatrix;
		_worldShader._ProjMatrix = _ProjMatrix;

		//prospective View (matrix)
		_matrixProxy.IdentityF(_ProjMatrix);
		float _fov = 90.0f;  // ------- feild Of View
		float _ZoomIn = 0.1f;
		float _ZoomOut = 100.0f;
		float _prosFloat;  // -----------------!!!!

		ogl.GetAspectRatio(_prosFloat);
		_matrixProxy.ProjectionOpenGLLHF(1.1344, _prosFloat, _ZoomIn, _ZoomOut, _worldShader._ProjMatrix); // 
		_matrixProxy.MultiplyMatrixF(_veiwMatrix, _ProjMatrix, _view_AND_Perspective);

		////ini Griddy-Grid (A)
		_matrixProxy.IdentityF(_Griddy_McGrid_face);
		GW::MATH::GVECTORF grid_A = { grid_A.x = 1.0f, grid_A.y = 0.0f, grid_A.z = 0.0f, grid_A.w = 1.0f };
		_matrixProxy.RotateYGlobalF(_Griddy_McGrid_face, 3.14 / 2, _Griddy_McGrid_face);
		_matrixProxy.TranslateGlobalF(_Griddy_McGrid_face, grid_A, _Griddy_McGrid_face);

		//ini Griddy-Grid (B)
		_matrixProxy.IdentityF(_Griddy_McGrid_LeftCheek);
		GW::MATH::GVECTORF grid_B = { grid_B.x = -1.0f, grid_B.y =  0.0f, grid_B.z =  0.0f, grid_B.w =  1.0f };
		_matrixProxy.RotateYGlobalF(_Griddy_McGrid_LeftCheek, 3.14 / 2, _Griddy_McGrid_LeftCheek);
		_matrixProxy.TranslateGlobalF(_Griddy_McGrid_LeftCheek, grid_B, _Griddy_McGrid_LeftCheek);

		//ini Griddy-Grid (C)
		_matrixProxy.IdentityF(_Griddy_McGrid_RightCheek);
		GW::MATH::GVECTORF grid_C = { grid_C.x = 0.0f, grid_C.y = 0.0f, grid_C.z = 1.0f, grid_C.w = 1.0f };
		_matrixProxy.RotateZGlobalF(_Griddy_McGrid_RightCheek, 3.14 / 2, _Griddy_McGrid_RightCheek);
		_matrixProxy.TranslateGlobalF(_Griddy_McGrid_RightCheek, grid_C, _Griddy_McGrid_RightCheek);


	    //ini Griddy-Grid (D)
		_matrixProxy.IdentityF(_Griddy_McGrid_BackCheeks);
		GW::MATH::GVECTORF grid_D = { grid_D.x =  0.0f, grid_D.y =  0.0f, grid_D.z = -1.0f, grid_D.w =  1.0f };
		_matrixProxy.RotateZGlobalF(_Griddy_McGrid_BackCheeks, 3.14 / 2, _Griddy_McGrid_BackCheeks);
		_matrixProxy.TranslateGlobalF(_Griddy_McGrid_BackCheeks, grid_D, _Griddy_McGrid_BackCheeks);

		//ini Griddy-Grid (E)
		_matrixProxy.IdentityF(_Griddy_McGrid_Head);
		GW::MATH::GVECTORF grid_E = { grid_E.x =  0.0f, grid_E.y = -1.0f, grid_E.z =  0.0f, grid_E.w =  1.0f };
		_matrixProxy.RotateXGlobalF(_Griddy_McGrid_Head, 3.14 / 2, _Griddy_McGrid_Head);
		_matrixProxy.TranslateGlobalF(_Griddy_McGrid_Head, grid_E, _Griddy_McGrid_Head);

		////ini Griddy-Grid (F)
		_matrixProxy.IdentityF(_Griddy_McGrid_Feet);
		GW::MATH::GVECTORF grid_F = { grid_F.x = 0.0f, grid_F.y = 1.0f, grid_F.z = 0.0f, grid_F.w = 1.0f };
		_matrixProxy.RotateXGlobalF(_Griddy_McGrid_Feet, 3.14 / 2, _Griddy_McGrid_Feet);
		_matrixProxy.TranslateGlobalF(_Griddy_McGrid_Feet, grid_F, _Griddy_McGrid_Feet);


		InitializeGraphics();
	}

private:

	//Constructor helper functions
	void InitializeGraphics()
	{
		// In debug mode we link openGL errors to the console
#ifndef NDEBUG
		BindDebugCallback();
#endif
		InitializeVertexBuffer();
		CompileVertexShader();
		CompileFragmentShader();
		CreateExecutableShaderProgram();
	}

#ifndef NDEBUG
	void BindDebugCallback()
	{
		glEnable(GL_DEBUG_OUTPUT);
		glDebugMessageCallback(MessageCallback, 0);
	}
#endif

	void InitializeVertexBuffer()
	{
		// TODO: Part 1b (hint: optional)
		const int numHorizontalSquares = 25;
		const int numVerticalSquares = 25;
		const float gridSize = 2.0f;
		const float gridSpacing = gridSize / static_cast<float>(numHorizontalSquares);

		std::vector<Vertex> verts;

		// Generate horizontal lines
		for (int i = 0; i <= numHorizontalSquares; ++i)
		{
			float x =  -1.0f + i * gridSpacing;
			float y1 = -1.0f;
			float y2 =  1.0f;
			Vertex gridvertwex_A = { x, y1 ,0, 1 };
			verts.push_back(gridvertwex_A);
			gridvertwex_A.y = y2;
			verts.push_back(gridvertwex_A);

		}

		// Generate vertical lines
		for (int i = 0; i <= numVerticalSquares; ++i) {
			float x1 = -1.0f;
			float x2 = 1.0f;
			float y = -1.0f + i * gridSpacing;
			Vertex gridVertex_B = { x1, y , 0, 1 };
			verts.push_back(gridVertex_B);
			gridVertex_B.x = x2;
			verts.push_back(gridVertex_B);
			
		}

		CreateVertexBuffer(&verts[0], (verts.size() * sizeof(Vertex)));
		
	}

	void CreateVertexBuffer(const void* data, unsigned int sizeInBytes)
	{
		glGenVertexArrays(1, &vertexArray);
		glGenBuffers(1, &vertexBufferObject);
		glBindVertexArray(vertexArray);
		glBindBuffer(GL_ARRAY_BUFFER, vertexBufferObject);
		glBufferData(GL_ARRAY_BUFFER, sizeInBytes, data, GL_STATIC_DRAW);
	}

	void CompileVertexShader()
	{
		char errors[1024];
		GLint result;

		vertexShader = glCreateShader(GL_VERTEX_SHADER);

		std::string vertexShaderSource = ReadFileIntoString("../Shaders/VertexShader.glsl");
		const char* strings[1] = { vertexShaderSource.c_str() };
		const GLint lengths[1] = { vertexShaderSource.length() };
		glShaderSource(vertexShader, 1, strings, lengths);

		glCompileShader(vertexShader);
		glGetShaderiv(vertexShader, GL_COMPILE_STATUS, &result);

		if (result == false)
		{
			glGetShaderInfoLog(vertexShader, 1024, NULL, errors);
			PrintLabeledDebugString("Vertex Shader Errors:\n", errors);
			abort();
			return;
		}
	}

	void CompileFragmentShader()
	{
		char errors[1024];
		GLint result;

		fragmentShader = glCreateShader(GL_FRAGMENT_SHADER);

		std::string fragmentShaderSource = ReadFileIntoString("../Shaders/FragmentShader.glsl");
		const char* strings[1] = { fragmentShaderSource.c_str() };
		const GLint lengths[1] = { fragmentShaderSource.length() };
		glShaderSource(fragmentShader, 1, strings, lengths);

		glCompileShader(fragmentShader);
		glGetShaderiv(fragmentShader, GL_COMPILE_STATUS, &result);

		if (result == false)
		{
			glGetShaderInfoLog(fragmentShader, 1024, NULL, errors);
			PrintLabeledDebugString("Fragment Shader Errors:\n", errors);
			abort();
			return;
		}
	}

	void CreateExecutableShaderProgram()
	{
		char errors[1024];
		GLint result;

		shaderExecutable = glCreateProgram();
		glAttachShader(shaderExecutable, vertexShader);
		glAttachShader(shaderExecutable, fragmentShader);
		glLinkProgram(shaderExecutable);
		glGetProgramiv(shaderExecutable, GL_LINK_STATUS, &result);
		if (result == false)
		{
			glGetProgramInfoLog(shaderExecutable, 1024, NULL, errors);
			std::cout << errors << std::endl;
		}
	}


public:
	void UpdateCamera()
	{
		static auto Timeplus = std::chrono::system_clock::now();
		auto Timeplus2 = std::chrono::system_clock::now();
		float delta = std::chrono::duration_cast<std::chrono::seconds>(Timeplus2 - Timeplus).count();

		// TODO: Part 4c
		_matrixProxy.InverseF(_veiwMatrix, _worldCameraMan);

		//// TODO: Part 4d
		float totalY = 0;
		float totalX = 0;
		float totalZ = 0;
		float tP = 0;
		float tYAW = 0;

		const float camera_speed = 0.0003f;
		float aspectratio = 0;
		float space_bar = 0;
		float left_Shift = 0;
		float rightT = 0;
		float leftT = 0;

		_GInput.GetState(23, space_bar);
		_GInput.GetState(14, left_Shift);
		_GController.GetState(0, 7, rightT);
		_GController.GetState(0, 6, leftT);

		////TODO: Part 4e
		float W = 0;
		float S = 0;
		float LSY = 0;
		_GInput.GetState(60, W);
		_GInput.GetState(56, S);
		_GController.GetState(0, 17, LSY);

		totalZ = W - S + LSY;
		float D = 0;
		float A = 0;
		float LSX = 0;
		_GInput.GetState(41, D);
		_GInput.GetState(38, A);
		_GController.GetState(0, 16, LSX);
		totalX = D - A + LSX;

		//// TODO: Part 4f
		float MYD = 0;
		float MXD = 0;
		float RSY = 0;
		_GController.GetState(0, 19, RSY);

		// TODO: Part 4g
		float RSX = 0;
		_GController.GetState(0, 18, RSX);
		ogl.GetAspectRatio(aspectratio);
		GW::GReturn result = _GInput.GetMouseDelta(MXD, MYD);
		totalY = left_Shift - space_bar + rightT - leftT;
		GW::MATH::GVECTORF cam = _worldCameraMan.row4;

		if (G_PASS(result) && result != GW::GReturn::REDUNDANT || (RSY != 0 || RSX != 0))
		{
			delta = delta * G_PI;
			tP = G_DEGREE_TO_RADIAN(65) * (MXD / 800) + (-RSY / 300) * delta;
			tYAW = G_DEGREE_TO_RADIAN(65) * aspectratio * (-MYD / 600) + (RSX / 300);
			totalY = totalY * camera_speed;
			_matrixProxy.RotateYGlobalF(_worldCameraMan, tP, _worldCameraMan);
			_matrixProxy.RotateXLocalF(_worldCameraMan, tYAW, _worldCameraMan);
		}
		_worldCameraMan.row4 = cam;

		// TODO: Part 4c
		GW::MATH::GVECTORF Y = { 0.0f, totalY * camera_speed * delta, 0.0f, 1.0f };
		GW::MATH::GVECTORF XZ = { totalX * camera_speed * delta , 0.0, totalZ * camera_speed * delta, 1.0f };
		_matrixProxy.TranslateGlobalF(_worldCameraMan, Y, _worldCameraMan);
		_matrixProxy.TranslateLocalF(_worldCameraMan, XZ, _worldCameraMan);
		_matrixProxy.InverseF(_worldCameraMan, _veiwMatrix);
		_worldShader._MatrixView = _veiwMatrix;

	

	};
	void Render()
	{
		SetUpPipeline();

		GLint worldMatrixLocation = glGetUniformLocation(shaderExecutable, "worldMatrix");

		glUniformMatrix4fv(worldMatrixLocation, 1, GL_FALSE, (GLfloat*)&_worldShader._MatrixWorld);

		// Front of the QGrid
		glUniformMatrix4fv(worldMatrixLocation, 1, GL_FALSE, (GLfloat*)&_Griddy_McGrid_face);
		glDrawArrays(GL_LINES, 0, (26 * 2 * 2));

		////Back of the QGrid
		glUniformMatrix4fv(worldMatrixLocation, 1, GL_FALSE, (GLfloat*)&_Griddy_McGrid_LeftCheek);
		glDrawArrays(GL_LINES, 0, (26 * 2 * 2));

		//Bottom of the QGrid
		glUniformMatrix4fv(worldMatrixLocation, 1, GL_FALSE, (GLfloat*)&_Griddy_McGrid_Head);
		glDrawArrays(GL_LINES, 0, (26 * 2 * 2));
	
		//Left Side of the QLeft Side
		glUniformMatrix4fv(worldMatrixLocation, 1, GL_FALSE, (GLfloat*)&_Griddy_McGrid_BackCheeks);
		glDrawArrays(GL_LINES, 0, (26 * 2 * 2));

		// Right Side of The QGrid
		glUniformMatrix4fv(worldMatrixLocation, 1, GL_FALSE, (GLfloat*)&_Griddy_McGrid_RightCheek);
		glDrawArrays(GL_LINES, 0, (26 * 2 * 2));

		glUniformMatrix4fv(worldMatrixLocation, 1, GL_FALSE, (GLfloat*)&_Griddy_McGrid_Feet); /// --------------- BUG FIXED!
		glDrawArrays(GL_LINES, 0, (26 * 2 * 2));
		
		// some video cards(cough Intel) need this set back to zero or they won't display
		glBindVertexArray(0);
	}
private:
	void SetUpPipeline()
	{
		
		glUseProgram(shaderExecutable);
		glBindVertexArray(vertexArray);
		SetVertexAttributes();

		GLint worldMatrixView = glGetUniformLocation(shaderExecutable, "viewMatrix");
		glUniformMatrix4fv(worldMatrixView, 1, GL_FALSE, (GLfloat*)&_worldShader._MatrixView);

		GLint _projectionMatrix = glGetUniformLocation(shaderExecutable, "projectionMatrix");
		glUniformMatrix4fv(_projectionMatrix, 1, GL_FALSE, (GLfloat*)&_worldShader._ProjMatrix);

		

		// Set up the view port
		unsigned int width, height;
		win.GetClientWidth(width);
		win.GetClientHeight(height);
		glViewport(0, 0, width, height);

		// Clear the backbuffer
		glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
		glClear(GL_COLOR_BUFFER_BIT);

	}


	void SetVertexAttributes()
	{

		glVertexAttribPointer(0, 4, GL_FLOAT, GL_FALSE, 4 * sizeof(float), (void*)0); 
		glEnableVertexAttribArray(0);
	}

public:
	~Renderer()
	{
		// free resources
		glDeleteVertexArrays(1, &vertexArray);
		glDeleteBuffers(1, &vertexBufferObject);
		glDeleteShader(vertexShader);
		glDeleteShader(fragmentShader);
		glDeleteProgram(shaderExecutable);
	}
};
